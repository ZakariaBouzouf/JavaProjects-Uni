package com.blatt9.blatt9;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Blatt9Application {

	public static void main(String[] args) {
		SpringApplication.run(Blatt9Application.class, args);
	}

}
