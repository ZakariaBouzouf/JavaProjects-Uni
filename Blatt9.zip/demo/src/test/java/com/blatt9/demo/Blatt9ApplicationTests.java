package com.blatt9.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Blatt9ApplicationTests {

	@Test
	void contextLoads() {
	}

}
