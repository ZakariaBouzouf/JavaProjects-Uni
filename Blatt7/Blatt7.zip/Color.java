public enum Color {
    BLACK,
    RED,
    ORANGE,
    WHITE;

    // public String toString(){
    //     return String.format("%s",COLOR);
    // }

}
