abstract class Vehicule {
    protected int id;

    public Vehicule(int id){
        this.id = id;
    }
}
